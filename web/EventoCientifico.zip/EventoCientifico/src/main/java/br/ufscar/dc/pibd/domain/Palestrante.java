package br.ufscar.dc.pibd.domain;

public class Palestrante {

}
