package br.ufscar.dc.pibd.domain;

public class Trabalho {

}
